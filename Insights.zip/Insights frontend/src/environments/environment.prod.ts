export const environment = {
  production: true,
  path:'http://localhost:8765/Insights/LoginAPI'
};
