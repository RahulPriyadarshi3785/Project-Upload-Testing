export class Batch{
    public batch_id:string 
	public batchname:string 
	
}