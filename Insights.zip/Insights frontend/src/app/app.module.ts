import { BookConcertService } from './book-concert/book-concert.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookConcertComponent } from './book-concert/book-concert.component';
import { HttpModule } from "@angular/http";
import { TraineeWorkspaceComponent } from './trainee-workspace/trainee-workspace.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminLoginService } from './admin-login/admin-login.service';
import { AdminWorkspaceComponent } from './admin-workspace/admin-workspace.component';
import { SeatComponent } from './seat/seat.component';
import { CourseDetailsService } from './trainee-workspace/course-details.service';
import { BatchDetailsService } from './admin-workspace/batch-details.service';
import { AuthService } from './auth.service';
import { AuthGuard } from './auth.guard';
import { RoleGuardService } from './role-guard.service';
import { DoubtService } from './trainee-workspace/doubt.service';
import { Doubt } from './seat/doubt.service';


@NgModule({
  declarations: [
    AppComponent,
    BookConcertComponent,
    TraineeWorkspaceComponent,
    AdminLoginComponent,
    AdminWorkspaceComponent,
    SeatComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    
  ],
  providers: [BookConcertService,AdminLoginService,
    CourseDetailsService,BatchDetailsService,AdminWorkspaceComponent,AuthService,AuthGuard,
    RoleGuardService,DoubtService,Doubt],
  bootstrap: [
    AppComponent
   ]
})
export class AppModule { }
