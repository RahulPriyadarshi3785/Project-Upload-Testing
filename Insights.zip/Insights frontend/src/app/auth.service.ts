import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {
  private loggedIn:string = localStorage.getItem('isloggedIn');
  constructor() { }

  setLoggedIn(status:string){
    this.loggedIn=status;
    localStorage.setItem('isloggedIn',this.loggedIn)
  }

  isLoggedIn():boolean{
    return this.loggedIn!=null || localStorage.getItem('isloggedIn')!=null;
  }
}
