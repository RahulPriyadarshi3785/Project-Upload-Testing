import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AdminLoginService } from './admin-login.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent {

  errorMessage: any;
  successMessage: any;
  loginForm: FormGroup;
  loginDetail: any;
  
  constructor(private fb: FormBuilder, private adminLoginService: AdminLoginService, private router: Router,
    private authServe: AuthService) { }

  loginA(traineeId,password) {
    this.successMessage = null;
    this.errorMessage = null;
   this.adminLoginService.loginA(this.loginForm.value)
      .then(response => {
        this.successMessage = response;
        this.loginDetail=response;
       // alert(this.successMessage)
       this.authServe.setLoggedIn('Admin');
       localStorage.setItem("isLoggedin", JSON.stringify('Admin'));
       localStorage.setItem('loginSessUser', JSON.stringify(this.loginDetail));
        this.router.navigate(['/adminw']);
      })
      .catch(error => {        
        this.errorMessage ="Invalid Credentials";
        
      })
  }
  

  ngOnInit() {
    this.loginForm = this.fb.group({
      adminId: ['', [Validators.required,Validators.pattern('A[0-9]{6}')]],
      password: ['', [Validators.required,Validators.pattern('@[A-Za-z0-9]{4,}')]]
      
    });
  }


 
}
