import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { environment } from '../../environments/environment.prod';

@Injectable()
export class BookConcertService {

  constructor(private http: Http) { }

  
  username:any;

  login(data) :Promise<any>{
    
    
    return this.http.post(environment.path+'/Trainee_detail2/',data)
      .toPromise()
      .then(response => {
        //this.username=data.traineeId
        console.log(data)
        localStorage.setItem('traineeId',data.traineeId);
        return response.json()
      })
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
  console.error("Error occured",error);  
  
  return Promise.reject(error.message || error);
  }

}  

