import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { BookConcertService } from './book-concert.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { environment } from '../../environments/environment.prod';


@Component({
  selector: 'app-book-concert',
  templateUrl: './book-concert.component.html',
  styleUrls: ['./book-concert.component.css']
})
export class BookConcertComponent implements OnInit {

  errorMessage: any;
  successMessage: any;
  loginForm: FormGroup;
  loginDetail: any;
  
  constructor(private fb: FormBuilder, private bookConcertService: BookConcertService, 
    private router: Router,private authServe: AuthService) { }

  login(traineeId,password) {
    this.successMessage = null;
    this.errorMessage = null;
    
    this.bookConcertService.login(this.loginForm.value)
      .then(response => {
        this.successMessage = response;
        this.loginDetail=response;
        this.authServe.setLoggedIn('Trainee');
          localStorage.setItem("isLoggedin", JSON.stringify('Trainee'));
          localStorage.setItem('loginSessUser', JSON.stringify(this.loginDetail));
                  //alert(this.bookConcertService.username)
        this.router.navigate(['/traineew']);
      })
      .catch(error => {        
        this.errorMessage ="Invalid Credentials";
        //alert(this.errorMessage)
      })
  }
 

  ngOnInit() {
    
    
    
    this.loginForm = this.fb.group({
      traineeId: ['', [Validators.required,Validators.pattern('T[0-9]{6}')]],
      password: ['', [Validators.required,Validators.pattern('@[A-Za-z0-9]{4,}')]]
      // checkbox:['',[Validators.requiredTrue]]
      
    });
  }

}   