import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { CourseDetailsService } from './course-details.service';
import { BookConcertService } from '../book-concert/book-concert.service';
import { Router } from '@angular/router';
import { Course } from '../course';
import { DoubtService } from './doubt.service';

@Component({
  selector: 'app-trainee-workspace',
  templateUrl: './trainee-workspace.component.html',
  styleUrls: ['./trainee-workspace.component.css']
})
export class TraineeWorkspaceComponent implements OnInit {
  doubtForm:FormGroup;
  successMessage:string;
  list:Course[];
  done:string;
  
  errorMessage: any;
  constructor(private fbb: FormBuilder, private courseDetailsService:CourseDetailsService, 
    private router: Router,private  obj:BookConcertService,private doubtService:DoubtService ) { }
  value() {
    this.successMessage = null;
    this.courseDetailsService.fetch()
      .then(response =>this.list = response
        //alert(this.list)
        //this.router.navigate(['/traineew']);
      )
      .catch(error => {        
        this.errorMessage =error;
        //alert(this.errorMessage)
      })
  }

  ngOnInit() {
    this.value();
    //alert(this.obj.username)
    this.doubtForm = this.fbb.group({
      fa: ['', [Validators.required]],
     
      description: ['', [Validators.required]]
      
    });
  }
  doubt( fa,description) {
    this.successMessage = null;
    this.errorMessage = null;
    
    this.doubtService.doubt(this.doubtForm.value)
      .then(response => {
        this.successMessage = response;
       this.done="Your doubt has been raised successfully"
      })
      .catch(error =>{       
        this.errorMessage =error})
  }
  logout(){
    localStorage.clear();
    this.router.navigate(['/login'])
  }
}
