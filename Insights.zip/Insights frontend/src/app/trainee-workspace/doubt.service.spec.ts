import { TestBed, inject } from '@angular/core/testing';

import { DoubtService } from './doubt.service';

describe('DoubtService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DoubtService]
    });
  });

  it('should be created', inject([DoubtService], (service: DoubtService) => {
    expect(service).toBeTruthy();
  }));
});
