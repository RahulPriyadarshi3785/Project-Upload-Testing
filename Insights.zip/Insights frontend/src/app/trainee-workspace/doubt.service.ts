import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { environment } from '../../environments/environment.prod';

@Injectable()
export class DoubtService {
traineeId:any=localStorage.getItem('traineeId')
  constructor(private http: Http) { }
  doubt(data) :Promise<any>{
    
    return this.http.get(environment.path+'/TraineeDoubtDescription/'+data.description+'/'+this.traineeId)
      .toPromise()
      .then(response =>response)
      .catch(this.errorHandler);
  }
  private errorHandler(error:any):Promise<any> {
     
  return Promise.reject(error.message || error);
  }
}
