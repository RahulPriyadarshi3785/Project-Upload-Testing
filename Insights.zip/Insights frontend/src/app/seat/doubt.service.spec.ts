import { TestBed, inject } from '@angular/core/testing';

import { Doubt } from './doubt.service';

describe('Doubt.ServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Doubt]
    });
  });

  it('should be created', inject([Doubt], (service: Doubt) => {
    expect(service).toBeTruthy();
  }));
});
