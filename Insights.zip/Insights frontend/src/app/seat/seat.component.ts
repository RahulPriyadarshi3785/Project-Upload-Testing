import { Component, OnInit } from '@angular/core';
import { AdminWorkspaceComponent } from '../admin-workspace/admin-workspace.component';
import { Router } from '@angular/router';
import { BatchDetailsService } from '../admin-workspace/batch-details.service';
import { Doubt } from './doubt.service';
import { FormGroup } from '@angular/forms/src/model';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-seat',
  templateUrl: './seat.component.html',
  styleUrls: ['./seat.component.css']
})

export class SeatComponent implements OnInit {
  
seatList:any[] =[];
  class:string
  sucessMessage:any;
  
  errorMessage: any;
  traineeId:any;
  traineeName:any;
  doubtList:any[]=[];
  list:any[]=[];
  deleteForm:FormGroup;
  title = 'seat-chart-generator';


  constructor(private adminWorkspaceComponent:AdminWorkspaceComponent,
    private router: Router,private batchDetailsService:BatchDetailsService,private doubt:Doubt,private fbb: FormBuilder) { }
  submit(){ 
   
    this.batchDetailsService.seats()
    .then(response=>{
      this.seatList= response
      for(let c of this.seatList){
        
        this.changeSeatColor(c)
        }
    })
    .catch(error => {        
      this.errorMessage =error;
      //alert(this.errorMessage)
    })}
  ngOnInit():void {
    this.submit();
    this.class=localStorage.getItem('class')
    var section = this.class.slice(14,17)
    localStorage.setItem("section",section)
    this.deleteForm = this.fbb.group({
      request: ['', [Validators.required]],
     
    
      
    });
    
  }
  changeSeatColor(seatNo){
    let id= document.getElementById(seatNo)
    id.innerHTML=`<img src="../assets/img/fseat.png" width="30px">`

  }
logout(){
  localStorage.clear();
  this.router.navigate(['/loginA'])
}
myFunction(seat:any) {
  this.list = [];
  this.doubt.doubtFetch(seat)
  .then(response=>{
       this.doubtList=response
  })
  .catch(error => {        
    this.errorMessage ="No Doubt Found";

    alert(this.errorMessage)
  this.traineeId=null;
  this.traineeName=null;
  this.list=[]; 
  })
  this.traineeId=this.doubtList[0];
  this.traineeName=this.doubtList[1];
  for(let i = 2; i < this.doubtList.length; i++){
    this.list.push(this.doubtList[i]) 
  }
  var popup = document.getElementById("myPopup");

  popup.classList.toggle("show");
  this.doubtList = [];
}
delete(){
  this.sucessMessage=null;
  this.errorMessage=null;
this.doubt.delete(this.traineeId,this.deleteForm.get("request").value)
.then(response=>{
  this.sucessMessage="The selected request has been deleted successfully"
  alert(this.sucessMessage)
})
.catch(error => {        
  this.errorMessage =error;
  alert(this.errorMessage)
})
}

}