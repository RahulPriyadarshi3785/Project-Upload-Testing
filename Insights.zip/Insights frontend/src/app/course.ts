export class Course{
    public Course_id: number 
    public Course_name: string 
}