import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from './auth.service';


@Injectable()
export class RoleGuardService implements CanActivate {
 
  constructor(private authService: AuthService, private router: Router) { }

  canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot): boolean {

    let expectedRole:string = route.data.expectedRole;
    let token:string = localStorage.getItem('isloggedIn');
    
    if (!this.authService.isLoggedIn() || token !== expectedRole) {
      if(token=='Admin')
        this.router.navigate(['/adminw']);// we can use sweet alert the navigate back
      else
        this.router.navigate(['/traineew']);
      return false;
    }
    return true;
  }

}
