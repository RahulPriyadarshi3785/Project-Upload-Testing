package com.infy.dao;

import com.infy.model.Admin;
import com.infy.model.Trainee;

public interface InsightsDAO {
	public Trainee getTraineeLoginByLoginName(String userName) throws Exception;
	public Admin getAdminLoginByLoginName(String userName) throws Exception;
	public Trainee getTraineeCourseDetails(String username) throws Exception;
	public Admin getAdminBatchDetails(String username);
	public Integer getTraineeUsername(String section,Integer seat) throws Exception; 
}
