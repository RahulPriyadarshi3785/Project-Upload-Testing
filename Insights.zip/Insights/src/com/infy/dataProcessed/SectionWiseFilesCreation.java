package com.infy.dataProcessed;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.infy.service.InsightsService;

public class SectionWiseFilesCreation {
	
	final static String frontEndPath = "C:/Users/hameer.TRN.ITLINFOSYS/workspace/ConcertsInTown_FrontEnd/src/assets/sectionWiseRequests";
	
	public static void createSectionWiseFiles(InsightsService service){
		try {
            FileInputStream myxls = new FileInputStream(InsertFileCreation.filename);
            HSSFWorkbook workbook = new HSSFWorkbook(myxls);
            HSSFSheet sheet = workbook.getSheetAt(0);

    		HashSet<String> sections = new HashSet<>();
    		for(File file: new File(frontEndPath).listFiles()){
    			sections.add(file.getName().replace(".xls", ""));
    		}
    		List<Integer> employeeId = new ArrayList<>();
    		List<String> name = new ArrayList<>();
    		List<String> request = new ArrayList<>();
    		List<Integer> seatNumber = new ArrayList<>();
    		List<String> sectionStudent = new ArrayList<>();
    		
            Iterator<Row> rowIterator = sheet.iterator();
    	    rowIterator.next();
    	    while (rowIterator.hasNext()){
                Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                Cell cell = cellIterator.next();
        		
        		
                String secBatch = service.getSeatBatch("T" + String.valueOf((int)cell.getNumericCellValue()));
        		
        		employeeId.add((int)cell.getNumericCellValue());
        		name.add(cellIterator.next().getStringCellValue());
        		request.add(cellIterator.next().getStringCellValue());
        		seatNumber.add(Integer.parseInt(secBatch.split("-")[0]));
        		sectionStudent.add(secBatch.split("-")[1]);
    	   }
   	    writeToSectionFiles(sections, employeeId, name, request, seatNumber, sectionStudent);
    	workbook.close();
      	}catch(Exception ex1){
      		ex1.printStackTrace();
      	}
//		DeleteFiles.deleteUndesiredFile(InsertFileCreation.filename);
    }
	
	public static void writeToSectionFiles(HashSet<String> sections, List<Integer> employeeId, List<String> name, List<String> request, List<Integer> seatNumber, List<String> sectionStudent){
		Integer len = employeeId.size();
		for(Integer i = 0; i < len; i++){
			if(!sections.contains(sectionStudent.get(i))){
				try{
		            HSSFWorkbook workbook1 = new HSSFWorkbook();
		            HSSFSheet sheet1 = workbook1.createSheet("FirstSheet");  
		
		            System.out.println("Header writing");
		            HSSFRow rowhead1 = sheet1.createRow((int)0);
		            rowhead1.createCell(0).setCellValue("EmployeeID");
		            rowhead1.createCell(1).setCellValue("Name");
	        		rowhead1.createCell(2).setCellValue("Request");
	        		rowhead1.createCell(3).setCellValue("SeatNumber");
		            
		            FileOutputStream fileOut1 = new FileOutputStream(frontEndPath + "/" + sectionStudent.get(i) + ".xls");
		            workbook1.write(fileOut1);
		            fileOut1.close();
		            workbook1.close();
		            sections.add(sectionStudent.get(i));
		            //System.out.println("Excel file Working.");
	
		        } catch ( Exception ex1 ) {
		            System.out.println(ex1);
		        }
			}
			try {
	            FileInputStream myxls2 = new FileInputStream(frontEndPath + "/" + sectionStudent.get(i) + ".xls");
		       	HSSFWorkbook workbook2 = new HSSFWorkbook(myxls2);
		        HSSFSheet sheet2 = workbook2.getSheetAt(0); 
	            Integer lastRow = sheet2.getLastRowNum();
		        System.out.println(lastRow);
	            HSSFRow row2 = sheet2.createRow((int)++lastRow);
	            row2.createCell(0).setCellValue(employeeId.get(i));
	            row2.createCell(1).setCellValue(name.get(i));
	            //System.out.println("x" + request.get(i));
	            row2.createCell(2).setCellValue(request.get(i));
	            row2.createCell(3).setCellValue(seatNumber.get(i));
		        
		            
	            FileOutputStream fileOut2 = new FileOutputStream(frontEndPath + "/" + sectionStudent.get(i) + ".xls");
	            workbook2.write(fileOut2);
	            fileOut2.close();
	            workbook2.close();
			} catch ( Exception ex2 ) {
		  		System.out.println(ex2);
		  	}
		}
	}
}
