package com.infy.dataProcessed;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import com.infy.service.InsightsService;


public class SectionWiseFilesDeletion {
	public static void deleteFromSectionFiles(InsightsService service){
		List<String> requests = new ArrayList<>();
		List<Integer> employeeId = new ArrayList<>();
		try {
            FileInputStream myxls = new FileInputStream(DeleteFileCreation.deleteFileName);
            HSSFWorkbook workbook = new HSSFWorkbook(myxls);
            HSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
    	    rowIterator.next();
    	    while (rowIterator.hasNext()){
    	    	Row row = rowIterator.next();
                Iterator<Cell> cellIterator = row.cellIterator();
                employeeId.add((int)cellIterator.next().getNumericCellValue());
                cellIterator.next();
                requests.add(cellIterator.next().getStringCellValue());
    	    }
    	    workbook.close();
    	}catch(Exception e){
    		e.printStackTrace();
    	}
		deleteRequestUtility(employeeId, requests, service);
	}
	

    public static void deleteRow(HSSFSheet sheet, int rowIndex) throws Exception{
    	int lastRowNum=sheet.getLastRowNum();
        if(rowIndex>=0&&rowIndex<lastRowNum){
        	sheet.shiftRows(rowIndex+1,lastRowNum, -1);
        }
        if(rowIndex==lastRowNum){
            HSSFRow removingRow=sheet.getRow(rowIndex);
            if(removingRow!=null){
                sheet.removeRow(removingRow);
            }
        }
    }
    
    public static void deleteRequest(HSSFSheet sheet, Integer employeeId, String request) throws Exception{
        Iterator<Row> rowIterator = sheet.iterator();
        rowIterator.next();
        while (rowIterator.hasNext()){
        	Row row = rowIterator.next();
            if(row.getCell(2).getStringCellValue().equals(request) && (int)row.getCell(0).getNumericCellValue() == employeeId){
            	deleteRow(sheet, row.getRowNum());
            	break;
            }
        }
        
        
}
    
    public static void deleteRequestUtility(List<Integer> employeeIds, List<String> requests, InsightsService service){
        Integer len = employeeIds.size();
    	for(Integer i = 0; i < len; i++){
    		
    		try {
    			String secSeat = service.getSeatBatch("T" + String.valueOf(employeeIds.get(i)));
                FileInputStream myxls = new FileInputStream(SectionWiseFilesCreation.frontEndPath + "/" + secSeat.split("-")[1] + ".xls");
                HSSFWorkbook workbook = new HSSFWorkbook(myxls);
                HSSFSheet sheet = workbook.getSheetAt(0);
                deleteRequest(sheet, employeeIds.get(i), requests.get(i));
                FileOutputStream outxls = new FileOutputStream(SectionWiseFilesCreation.frontEndPath + "/" + secSeat.split("-")[1] + ".xls");
                workbook.write(outxls);
        	    workbook.close();
        	}catch(Exception e){
        		e.printStackTrace();
        	}
    	}
    }

}
