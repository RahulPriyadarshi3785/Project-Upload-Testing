package com.infy.dataProcessed;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class SectionWiseSeatWithRequest {
	public static List<Integer> seatWithRequests(String section){
		List<Integer> seatNumberWithRequests = new ArrayList<>();
		HashSet<Integer> Uniqueseats = new HashSet<>();
		try {
            FileInputStream myxls = new FileInputStream(SectionWiseFilesCreation.frontEndPath + "/" + section + ".xls");
            HSSFWorkbook workbook = new HSSFWorkbook(myxls);
            HSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();            
            rowIterator.next();
    	    while (rowIterator.hasNext()){
                Iterator<Cell> cellIterator = rowIterator.next().cellIterator();
                cellIterator.next();
                cellIterator.next();
                cellIterator.next();
                Uniqueseats.add((int)cellIterator.next().getNumericCellValue());
    	    }
    	    workbook.close();
    	    for(Integer seat: Uniqueseats)
    	    	seatNumberWithRequests.add(seat);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return seatNumberWithRequests;
	}
}
