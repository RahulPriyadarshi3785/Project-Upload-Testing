package com.infy.dataProcessed;

import java.util.List;

public class DetailsWithRequestTrainee{
	public Integer traineeId;
	String traineeName;
	List<String> requestOfTrainee;
	public DetailsWithRequestTrainee(Integer traineeId, String traineeName, List<String> requestOfTrainee){
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.requestOfTrainee = requestOfTrainee;
	}
}