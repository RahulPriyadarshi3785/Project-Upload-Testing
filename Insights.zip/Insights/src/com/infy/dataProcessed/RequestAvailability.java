package com.infy.dataProcessed;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class RequestAvailability {

	public static List<String> returnRequestsAvailable(){
		List<String> rtAvailable = new ArrayList<String>();
		try {
			File[] files = new File(InsertFileCreation.pathname).listFiles();
			for(File file: files){
				XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(file));
	            if(workbook.getSheetAt(0).getLastRowNum() > 1)
	            	rtAvailable.add(file.getPath().substring(file.getParent().length() + 1, file.getPath().length() - 5));
	            
	            workbook.close();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return rtAvailable;
	}
	
	
}
