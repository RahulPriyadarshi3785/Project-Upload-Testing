package com.infy.dataProcessed;

import java.io.File;
import java.util.Arrays;

import org.hibernate.SessionFactory;

import com.infy.dao.InsightsDaoImpl;
import com.infy.service.InsightsServiceImpl;

//import java.util.Arrays;

public class DummyTestRunInsights {
    
	public static void main(String... args){
//		RequestTrainees r1 = new RequestTrainees(563186, "Rahul Priyadarshi", "Angular ni ata h");
//		RequestTrainees r2 = new RequestTrainees(563189, "Hameer", "Kuch v ni ata h");
//		RequestTrainees r3 = new RequestTrainees(563186, "Rahul Priyadarshi", "Java v ni ata h");
//		RequestTrainees r4 = new RequestTrainees(563188, "Uday", "Python ni ata h");
//		RequestTrainees r5 = new RequestTrainees(563189, "Hameer", "Kuch v ni ata h");
//		RequestTrainees r6 = new RequestTrainees(563187, "Ichchha", "Collections v ni ata h");
//		RequestTrainees r7 = new RequestTrainees(563187, "Ichchha", "Stream v ni ata h");
//		for(int i = 0; i < 10; i++)
//			InsertFileCreation.createRequest(Arrays.asList(new RequestTrainees[]{r1, r2, r3, r4, r5, r6, r7}));
//		//Evabot trigger using rest api.
//		DeleteFiles.deleteUndesiredFile(InsertFileCreation.filename);//Called after Evabot Trigger
//		for(int i = 0; i < 10; i++)
//			DeleteFileCreation.deleteRequestList(Arrays.asList(new RequestTrainees[]{r1, r2, r1, r2, r1, r2, r1, r2}));
//		//Evabot trigger using rest api.
//		DeleteFiles.deleteUndesiredFile(DeleteFileCreation.deleteFileName);//Called after Evabot Trigger
//		try{
//			System.out.println(new InsightsServiceImpl().getTraineeUsername("SR3", 1));
//		}
//		catch(Exception e){
//			e.printStackTrace();
//			System.out.println("Error aa gya");
//		}
//		RequestsOfEmployee.requestsOfEmployee(563187);
//		System.out.println(new File("C:\\Users\\hameer.TRN.ITLINFOSYS\\workspace\\ConcertsInTown_FrontEnd\\src\\assets\\sectionWiseRequests\\SR3.xls").canRead());
		new RequestTrainees(563186,"hjuscg","gcdhiugcdi");
		//System.out.println(SectionWiseSeatWithRequest.seatWithRequests("SR3"));
		System.out.println("");
	}
	
}
