package com.infy.dataProcessed;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class InsertFileCreationUpdated {
	final static String pathname = "C:/Users/hameer.TRN.ITLINFOSYS/Documents/Insights" ;
    final static String filename = "C:/Users/hameer.TRN.ITLINFOSYS/Documents/DataInTake.xls" ;
	public static HashSet<Integer> availableFiles(HSSFSheet sheet) throws Exception{
		HashSet<Integer> employee = new HashSet<>();

	    Iterator<Row> rowIterator = sheet.iterator();
	    rowIterator.next();
	    while (rowIterator.hasNext())
	    {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            Cell cell = cellIterator.next();

//	            String data = "";
//	            if(cell.getCellType()==CellType.STRING) 
//	                data = cell.getStringCellValue(); 
//	            else if(cell.getCellType()==CellType.NUMERIC) 
//	                data = String.valueOf(cell.getNumericCellValue());
            employee.add((int)cell.getNumericCellValue());
	   }
		
		File[] directoryFiles = new File(pathname).listFiles();
		for(File file: directoryFiles){
			employee.add(Integer.parseInt(file.getName().replace(".xlsx", "")));
		}
		
		return employee;
	}
	
    public static void createRequest(List<RequestTraineesUpdated> rt) {
        try {
            FileInputStream myxls = new FileInputStream(filename);
            HSSFWorkbook workbook = new HSSFWorkbook(myxls);
            HSSFSheet sheet = workbook.getSheetAt(0); 
            Integer lastRow = sheet.getLastRowNum();
            HashSet<Integer> employee = availableFiles(sheet);
            
            for(RequestTraineesUpdated newRequest: rt){
	            HSSFRow row = sheet.createRow((int)++lastRow);
	            row.createCell(0).setCellValue(newRequest.employeeID);
	            row.createCell(1).setCellValue(newRequest.name);
	            row.createCell(2).setCellValue(newRequest.request);
	            if(employee.contains(newRequest.employeeID))
	            	row.createCell(3).setCellValue("Y");
	            else{
	            	row.createCell(3).setCellValue("N");
	            	employee.add(newRequest.employeeID);
	            }
	            row.createCell(4).setCellValue(newRequest.seatNumber);
	            row.createCell(5).setCellValue(newRequest.section);
            }
            
            FileOutputStream fileOut = new FileOutputStream(filename);
            workbook.write(fileOut);
            fileOut.close();
            workbook.close();
        } catch ( Exception ex ) {
            System.out.println(ex);
        }
    }
}
