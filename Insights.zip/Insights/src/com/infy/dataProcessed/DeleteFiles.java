package com.infy.dataProcessed;

import java.io.File;

public class DeleteFiles {

	public static void deleteUndesiredFile(String path){
		new File(path).delete();
	}
}
