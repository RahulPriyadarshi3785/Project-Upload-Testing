package com.infy.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

	@Entity
	@Table(name="Admin_details2")
	public class AdminEntity {
	                
	                private Integer id;
	                @Column(name="Admin_name")
	                private String name;
	                @Id
	                private String Username;
	                private String password;
	                @OneToMany(cascade = CascadeType.ALL)
	            	@JoinTable(name = "adminBatch_Link", 
	            	joinColumns = @JoinColumn(name = "A_Username", referencedColumnName = "Username"), 
	            	inverseJoinColumns = @JoinColumn(name = "BatchId", referencedColumnName = "batch_id",
	            	unique=true))
	                
	                public List<BatchEntity> batches;
	                
	                public Integer getId() {
	                	return id;
	                }
	                public void setId(Integer id) {
	                    this.id = id;
	                }
	                
	                public String getName() {
	                    return name;
	                }
	                public void setName(String name) {
	                    this.name = name;
	                }
	               
	                public String getUsername() {
						return Username;
					}
					public void setUsername(String username) {
						Username = username;
					}
					
					public String getPassword() {
		                    return password;
		            }
		            public void setPassword(String password) {
		                    this.password = password;
		            }
		            
					public List<BatchEntity> getBatches() {
	            		return batches;
	            	}
                    public void setBatches(List<BatchEntity> batches) {
	            		this.batches = batches;
	            	}
	                
	}


