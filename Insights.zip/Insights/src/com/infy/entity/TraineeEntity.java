package com.infy.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
//import javax.persistence.ManyToOne;
import javax.persistence.Table;

	@Entity
	@Table(name="Trainee_detail2")
	public class TraineeEntity {
	                
	                private Integer id;
	                @Column(name="Trainee_name")
	                private String name;	               
	                @Id
	                private String Username;
	                private String password;
	                private Integer SeatNumber;
	                
	                public Integer getSeatNumber() {
						return SeatNumber;
					}
					public void setSeatNumber(Integer SeatNumber) {
						this.SeatNumber = SeatNumber;
					}
					
					@ManyToMany(cascade = CascadeType.ALL)
	            	@JoinTable(name = "traineeCourse_Link", 
	            	joinColumns = @JoinColumn(name = "T_Username", referencedColumnName = "Username"), 
	            	inverseJoinColumns = @JoinColumn(name = "courseId", referencedColumnName = "Course_id"))
	                private List<CourseEntity> courses;
					
//					@ManyToOne(cascade=CascadeType.ALL)
//					@JoinColumn(name="batch_id")
//					private BatchEntity batch;
//	                
//	                public BatchEntity getBatch() {
//						return batch;
//					}
//					public void setBatch(BatchEntity batch) {
//						this.batch = batch;
//					}
					private String batch_id;
					
					
					public String getBatch_id() {
						return batch_id;
					}
					public void setBatch_id(String batch_id) {
						this.batch_id = batch_id;
					}
					
					
					public Integer getId() {
	                                return id;
	                }
	                public void setId(Integer id) {
	                                this.id = id;
	                }
	                public String getName() {
	                                return name;
	                }
	                public void setName(String name) {
	                                this.name = name;
	                }
	              
	                public String getUserName() {
	                                return Username;
	                }
	                public void setUserName(String userName) {
	                                this.Username = userName;
	                }
	                public String getPassword() {
                        return password;
	                }
	                public void setPassword(String password) {
                        this.password = password;
	                }
	                
	                public List<CourseEntity> getCourses() {
	            		return courses;
	            	}

	            	public void setCourses(List<CourseEntity> courses) {
	            		this.courses = courses;
	            	}

	}


