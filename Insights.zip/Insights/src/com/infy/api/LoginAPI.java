package com.infy.api;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.core.env.Environment;














import com.infy.dataProcessed.DeleteFileCreation;
import com.infy.dataProcessed.InsertFileCreation;
import com.infy.dataProcessed.RequestTrainees;
import com.infy.dataProcessed.RequestsOfEmployee;
import com.infy.dataProcessed.SectionWiseFilesCreation;
import com.infy.dataProcessed.SectionWiseSeatWithRequest;
import com.infy.model.Admin;
//import com.infy.model.RequestTrainees;
import com.infy.model.Trainee;
import com.infy.model.Course;
import com.infy.model.Batch;
import com.infy.service.*;
import com.infy.utility.ContextFactory;
import com.infy.utility.LogConfig;



@RestController
@CrossOrigin
@RequestMapping(value="LoginAPI")
public class LoginAPI {
	
	
	    private InsightsService service;

		
		@RequestMapping(method=RequestMethod.POST, value="/Trainee_detail2")
		public ResponseEntity<Trainee> getTraineeById(@RequestBody Trainee trainee){			
			
			Environment environment= ContextFactory.getContext().getEnvironment();
			service =  (InsightsService) ContextFactory.getContext().getBean(InsightsServiceImpl.class);
			System.out.println(trainee.getUserName() );
			System.out.println(trainee.getPassword());
			ResponseEntity<Trainee> responseEntity;
			try {
//				Trainee trainee1 = service.getTraineeLoginByLoginName(trainee.getUserName(),trainee.getPassword());
				//System.out.println("Before Trainee object");
				Trainee trainee1 = service.getTraineeLoginByLoginName(trainee.getUserName(),trainee.getPassword());
				//System.out.println(trainee.getUserName());
				LogConfig.getLogger(this.getClass()).info("Successful Logging", trainee.getUserName(), trainee.getName());
				//System.out.println("Logging done");
				responseEntity = new ResponseEntity<Trainee>(trainee1,HttpStatus.OK);

			}
			catch(Exception exception) {
				
				LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
				String errorMessage = environment.getProperty(exception.getMessage());
				//System.out.println("catch");
				Trainee trainee2 = new Trainee();
				trainee2.setMessage(errorMessage);
				responseEntity = new ResponseEntity<Trainee>(trainee2,HttpStatus.OK);				

			}

			return responseEntity;

		}
		
		
		
		@RequestMapping(method=RequestMethod.GET, value="/TraineeDoubtDescription/{request}/{traineeId}")
		public ResponseEntity<String> getTraineeDoubtDescription(@PathVariable String request, @PathVariable String traineeId){	
			//@PathVariable String traineeId
			//get value of traineeid from frontend	
			//make a setter method for loginId @traineelogin and getter method in other component where request is generated to fetch the same
			com.infy.dataProcessed.RequestTrainees.creatingHeaders();
			Environment environment= ContextFactory.getContext().getEnvironment();
			service =  (InsightsService) ContextFactory.getContext().getBean(InsightsServiceImpl.class);
			
			ResponseEntity<String> responseEntity;
		    try{
				Trainee trainee = service.getTraineeCourseDetails(traineeId);
				InsertFileCreation.createRequest(Arrays.asList(new com.infy.dataProcessed.RequestTrainees[]
						{ new com.infy.dataProcessed.RequestTrainees(trainee.getId(), trainee.getName(), request)}));
				//Evabot trigger using rest api.
			    //Thread.sleep(10000);
			    File file = new File(DeleteFileCreation.deleteFileName);
			    while(!file.canExecute() || !file.canWrite());
				SectionWiseFilesCreation.createSectionWiseFiles(service);
				//com.infy.dataProcessed.DeleteFiles.deleteUndesiredFile(com.infy.dataProcessed.InsertFileCreation.filename);//Called after Evabot Trigger
			    responseEntity = new ResponseEntity<String>(request,HttpStatus.OK);
		    }
			
			catch(Exception exception) {
				
				LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
				String errorMessage = environment.getProperty(exception.getMessage());
				Trainee trainee = new Trainee();
				trainee.setMessage(errorMessage);
    			responseEntity = new ResponseEntity<String>(errorMessage,HttpStatus.OK);
    		}

			return responseEntity;
		}
		

		@RequestMapping(method=RequestMethod.GET, value="/DeleteAdminRequest/{request}/{traineeId}")
		public ResponseEntity<String> deleteAdminRequest(@PathVariable String request, @PathVariable String traineeId){	
		    System.out.println(request +"----------------" + request.getClass() +"----------------" + traineeId +"----------------" + traineeId.getClass());		
			
			Environment environment= ContextFactory.getContext().getEnvironment();
			service =  (InsightsService) ContextFactory.getContext().getBean(InsightsServiceImpl.class);
			
			ResponseEntity<String> responseEntity;
			//System.out.println(traineeId);
		    try{
				Trainee trainee = service.getTraineeCourseDetails("T" + traineeId);
			    DeleteFileCreation.deleteRequestList(Arrays.asList(new RequestTrainees[]
			    		{new RequestTrainees(trainee.getId(), trainee.getName(), request)}));
				//Evabot trigger using rest api.
			    //Thread.sleep(10000);
			    File file = new File(DeleteFileCreation.deleteFileName);
			    while(!file.canExecute() || !file.canWrite());
			    com.infy.dataProcessed.SectionWiseFilesDeletion.deleteFromSectionFiles(service);
				//com.infy.dataProcessed.DeleteFiles.deleteUndesiredFile(com.infy.dataProcessed.DeleteFileCreation.deleteFileName);//Called after Evabot Trigger
			    responseEntity = new ResponseEntity<String>(request,HttpStatus.OK);
		    }
			
			catch(Exception exception) {
				
				LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
				String errorMessage = environment.getProperty(exception.getMessage());
				Trainee trainee = new Trainee();
				trainee.setMessage(errorMessage);
    			responseEntity = new ResponseEntity<String>(errorMessage,HttpStatus.OK);
    			
			}

			return responseEntity;

		}


		@RequestMapping(method=RequestMethod.POST, value="/Admin_details2")
		public ResponseEntity<Admin> getAdminById(@RequestBody Admin admin){	

				Environment environment= ContextFactory.getContext().getEnvironment();
				service =  (InsightsService) ContextFactory.getContext().getBean(InsightsServiceImpl.class);
				
				ResponseEntity<Admin> responseEntity;
				try {
					Admin admin1 = service.getAdminLoginByLoginName(admin.getUserName(),admin.getPassword());
					LogConfig.getLogger(this.getClass()).info("Successful Logging", admin.getUserName(), admin.getName());
					responseEntity = new ResponseEntity<Admin>(admin1,HttpStatus.OK);

				}
				catch(Exception exception) {	
					
					LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
					String errorMessage = environment.getProperty(exception.getMessage());
					Admin admin2 = new Admin();
					admin2.setMessage(errorMessage);
					responseEntity = new ResponseEntity<Admin>(admin2,HttpStatus.OK);

				}

				return responseEntity;

			}
		
		@RequestMapping(method=RequestMethod.GET, value="/Batch_details/{username}")
		
		public ResponseEntity<List<Batch>> getAdminBatchDetails(@PathVariable String username  ){
					
					Environment environment = ContextFactory.getContext().getEnvironment();
					InsightsServiceImpl service = ContextFactory.getContext().getBean(InsightsServiceImpl.class);
						
					ResponseEntity<List<Batch>> responseEntity;
					try {
						Admin admin = service.getAdminBatchDetails(username);
						responseEntity = new ResponseEntity<List<Batch>>(admin.getBatches(),HttpStatus.OK);

					}
					
					catch(Exception exception) {	
						
						LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
						String errorMessage = environment.getProperty(exception.getMessage());
						Admin admin = new Admin();
						admin.setMessage(errorMessage);
						responseEntity = new ResponseEntity<List<Batch>>(admin.getBatches(),HttpStatus.OK);
					}

					return responseEntity;
						
				}	
		@RequestMapping(method=RequestMethod.GET, value="/Admin/TraineeSection/{section}")
		
		public ResponseEntity<List<Integer>> getTraineeSection(@PathVariable String section  ){
						
					ResponseEntity<List<Integer>> responseEntity;
					List<Integer> seatList = new ArrayList<>();
					try {
						seatList = SectionWiseSeatWithRequest.seatWithRequests(section);
						//System.out.println(seatList);
						responseEntity = new ResponseEntity<List<Integer>>(seatList,HttpStatus.OK);

					}
					
					catch(Exception exception) {
						
						LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
						responseEntity = new ResponseEntity<List<Integer>>(seatList,HttpStatus.OK);
					}

					return responseEntity;
						
				}	
		
				
		@RequestMapping(method=RequestMethod.GET, value="/Course_detail2/{username}")
		
		public ResponseEntity<List<Course>> getTraineeCourseDetails(@PathVariable String username  ){
			
			Environment environment= ContextFactory.getContext().getEnvironment();
			InsightsServiceImpl service = ContextFactory.getContext().getBean(InsightsServiceImpl.class);		
			ResponseEntity<List<Course>> responseEntity;
			try {
				Trainee t = service.getTraineeCourseDetails(username);
				responseEntity = new ResponseEntity<List<Course>>(t.getCourses(),HttpStatus.OK);

			}
			
			catch(Exception exception) {

				LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
				String errorMessage = environment.getProperty(exception.getMessage());
				Trainee trainee = new Trainee();
				trainee.setMessage(errorMessage);
				responseEntity = new ResponseEntity<List<Course>>(trainee.getCourses(),HttpStatus.OK);

			}

			return responseEntity;
			
		}

		
		@RequestMapping(method=RequestMethod.GET, value="/TraineeSeatMapping/{section}/{seat}")
		public ResponseEntity<List<String>> getSectionNSeat(@PathVariable String section, @PathVariable Integer seat) throws Exception{	
			
			service =  (InsightsService) ContextFactory.getContext().getBean(InsightsServiceImpl.class);
			List<String> requestsOfEmployee = null;
			ResponseEntity<List<String>> responseEntity;
			Integer employeeId = 0;
			
			try{
		    	employeeId =service.getTraineeUsername(section,seat);
		    	requestsOfEmployee = RequestsOfEmployee.requestsOfEmployee(employeeId);
				responseEntity = new ResponseEntity<List<String>>(requestsOfEmployee,HttpStatus.OK);
			    
			}
			
			catch(Exception exception){
				
				LogConfig.getLogger(this.getClass()).info(exception.getMessage(), exception);
				responseEntity = new ResponseEntity<List<String>>(requestsOfEmployee,HttpStatus.OK);
				   
			}
			
		   
		        return responseEntity;
		}
		
		
	}

	


