//package com.infy.api;
//
//import org.springframework.core.env.Environment;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RestController;
//
//
//import com.infy.model.Trainee;
//import com.infy.service.InsightsService;
//import com.infy.utility.ContextFactory;
//
//
//@RestController
//@CrossOrigin
//@RequestMapping(value="TraineeCourseAPI")
//
//public class TraineeCourseAPI {
//	
//	@RequestMapping(method=RequestMethod.GET, value="/Trainee_detail2/{username}")
//	
//	public ResponseEntity<Trainee> getTraineeCourseDetails(@PathVariable String username  ){
//		
//		Environment environment= ContextFactory.getContext().getEnvironment();
//		InsightsService service = ContextFactory.getContext().getBean(InsightsService.class);		
//		ResponseEntity<Trainee> responseEntity;
//		try {
//			Trainee t = service.getTraineeCourseDetails(username);
//			responseEntity = new ResponseEntity<Trainee>(t,HttpStatus.OK);
//
//		}
//		catch(Exception exception) {				
//			String errorMessage = environment.getProperty(exception.getMessage());
//			Trainee trainee = new Trainee();
//			trainee.setMessage(errorMessage);
//			responseEntity = new ResponseEntity<Trainee>(trainee,HttpStatus.BAD_REQUEST);
//
//		}
//
//		return responseEntity;
//		
//	}
//
//}
