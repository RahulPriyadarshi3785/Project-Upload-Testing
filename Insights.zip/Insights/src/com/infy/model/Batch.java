package com.infy.model;


public class Batch {
	
	private String batch_id;
	private String batchname;
	
//	public Batch(){
//		
//	}
//	public Batch(BatchEntity be){
//		this.setBatch_id(be.getBatch_id());
//		this.setBatchname(be.getBatchname());
//	}
	public String getBatch_id() {
		return batch_id;
	}
	public void setBatch_id(String batch_id) {
		this.batch_id = batch_id;
	}
	public String getBatchname() {
		return batchname;
	}
	public void setBatchname(String batchname) {
		this.batchname = batchname;
	}
}
